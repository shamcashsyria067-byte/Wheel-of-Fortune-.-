const express=require("express"),Database=require("better-sqlite3"),crypto=require("crypto"),path=require("path");
const app=express(),db=new Database(process.env.DB_PATH||"contest.sqlite"),PORT=process.env.PORT||3000,ADMIN_TOKEN=process.env.ADMIN_TOKEN;
app.use(express.json({limit:"20kb"}));app.use(express.static(path.join(__dirname,"public")));
db.exec(`CREATE TABLE IF NOT EXISTS entries(id INTEGER PRIMARY KEY AUTOINCREMENT,phone TEXT NOT NULL UNIQUE,claim_code TEXT NOT NULL UNIQUE,prize TEXT NOT NULL,created_at TEXT NOT NULL)`);
const prizes=[{name:"1000 دولار",weight:1},{name:"آيفون 18",weight:1},{name:"رحلة عمرة",weight:1},{name:"سيارة",weight:1},{name:"حظ أوفر",weight:6}];
function choosePrize(){let n=crypto.randomInt(prizes.reduce((s,p)=>s+p.weight,0));for(const p of prizes){if(n<p.weight)return p.name;n-=p.weight}return prizes[4].name}
function phoneNorm(p){return String(p||"").replace(/[^\d+]/g,"").slice(0,18)}
app.get("/api/config",(_,r)=>r.json({title:process.env.CONTEST_TITLE||"عجلة الجوائز",prizes:prizes.map(p=>p.name)}));
app.post("/api/spin",(req,res)=>{const phone=phoneNorm(req.body.phone);if(phone.replace(/\D/g,"").length<8)return res.status(400).json({error:"أدخل رقم هاتف صحيحًا مع رمز الدولة."});
const old=db.prepare("SELECT prize,claim_code,created_at FROM entries WHERE phone=?").get(phone);if(old)return res.status(409).json({error:"هذا الرقم شارك سابقًا.",prize:old.prize,claimCode:old.claim_code,createdAt:old.created_at});
const prize=choosePrize(),claimCode="PW-"+crypto.randomBytes(5).toString("hex").toUpperCase(),createdAt=new Date().toISOString();
try{db.prepare("INSERT INTO entries(phone,claim_code,prize,created_at) VALUES(?,?,?,?)").run(phone,claimCode,prize,createdAt)}catch(e){return res.status(409).json({error:"تم تسجيل مشاركة لهذا الرقم."})}
res.json({prize,claimCode,createdAt})});
app.get("/api/admin/entries",(req,res)=>{if(!ADMIN_TOKEN||req.get("x-admin-token")!==ADMIN_TOKEN)return res.status(401).json({error:"غير مصرح. اضبط ADMIN_TOKEN في إعدادات الاستضافة."});res.json({entries:db.prepare("SELECT phone,claim_code,prize,created_at FROM entries ORDER BY id DESC").all()})});
app.get("/health",(_,r)=>r.json({ok:true}));app.listen(PORT,()=>console.log("Prize wheel listening on "+PORT));